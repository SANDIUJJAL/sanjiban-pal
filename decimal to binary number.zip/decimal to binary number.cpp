#include<stdio.h>
#include<conio.h>
int main()
{
int x,y, num,i,j;
printf("\n enter the numbers:");
scanf("%d",&num);
	while(num!=0)
	{
	num=num/2;
	x=num/2;
	y=num%2;
	printf("x,y ");
	
	}

}

	
	