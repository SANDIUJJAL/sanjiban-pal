#include<stdio.h>
#include<conio.h>
int DATA[10]={22,33,11,44,2,3,88,29,35,55};
int N=10;
VOID BUBBLE(void);
void main()
{
	int i;
	clrscr();
	printf("values contained in DATA [10]=");
	for(i=0;i<10;i++)
		printf("%d",DATA[i]);
	BUBBLE();
	Printf("\n\n value contained in DATA[10] AFTER SORTING=");
		for(i=0;i<10;i++)
			printf("%d",DATA[i]);
			getch();
}
void BUBBLE(VOID)
{
	int k,PTR,TEMP;
	for(k=0;k<=(N-1-1);K++)
	PTR=0;
	While(PTR<=(N-K-1-1))
	{
		
		
	}
}